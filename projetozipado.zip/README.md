# facu
DevOps 
Aqui devo testar alguns markdowns como *este aqui em itálico*.